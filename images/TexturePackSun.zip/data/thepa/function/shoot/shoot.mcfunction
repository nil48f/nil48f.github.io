
function thepa:utilities/select_hand_shoot

execute if entity @s[tag=gz_mainhand] run function thepa:shoot/mainhand
execute if entity @s[tag=gz_offhand] run function thepa:shoot/offhand

scoreboard players set @a[scores={shootingdelay=1},nbt=!{SelectedItem:{components:{"minecraft:custom_data":{gz_data:{id:15b}}}}},nbt=!{SelectedItem:{components:{"minecraft:custom_data":{gz_data:{id:31b}}}}}] shotcounterdelay 60
scoreboard players add @a[scores={shootingdelay=1},nbt=!{SelectedItem:{components:{"minecraft:custom_data":{gz_data:{id:15b}}}}},nbt=!{SelectedItem:{components:{"minecraft:custom_data":{gz_data:{id:31b}}}}}] shotcounter 1

scoreboard players add @e[scores={gz_id=25},tag=gz_shoot] gz_teslatimer 1

tag @s remove gz_shoot
tag @s remove gz_part_reload