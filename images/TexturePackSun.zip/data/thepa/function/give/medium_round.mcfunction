

give @s minecraft:clock[minecraft:custom_model_data=444449,minecraft:custom_data={"gz_data":{"bullet_type":6b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_6\",\"color\": \"white\",\"italic\": false}"] 16