

give @s minecraft:redstone[minecraft:custom_model_data=88921,minecraft:custom_data={"gz_data":{"suppressor":1b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.suppressor\",\"color\": \"white\",\"italic\": false}"]