

give @s minecraft:clock[minecraft:custom_model_data=444455,minecraft:custom_data={"gz_data":{"bullet_type":19b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_19\",\"color\": \"white\",\"italic\": false}"]