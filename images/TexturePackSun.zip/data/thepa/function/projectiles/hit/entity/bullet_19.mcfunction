
execute if entity @s run summon creeper ~ ~ ~ {Fuse:1b,ignited:1b,ExplosionRadius:3,CustomName:"\"an RPG\""}

execute positioned ^ ^ ^-0.2 run particle minecraft:block{block_state:{Name:"minecraft:light_gray_concrete"}} ~ ~ ~ 0 0 0 0 5
