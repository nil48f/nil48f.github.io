

give @s minecraft:clock[minecraft:custom_model_data=444452,minecraft:custom_data={"gz_data":{"bullet_type":11b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_11\",\"color\": \"white\",\"italic\": false}"]