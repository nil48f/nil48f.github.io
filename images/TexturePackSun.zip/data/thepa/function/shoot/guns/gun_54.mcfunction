
function thepa:projectiles/spawn/bullet_54 with entity @s

execute anchored eyes positioned ^ ^0.2 ^1.2 run particle minecraft:happy_villager ~ ~ ~ 0 0 0 0 1

execute if score GLOBAL camera matches 1 run function thepa:recoil_types/camera/gun_54

tag @s add bfguser
execute if score GLOBAL recoil matches 1 run tag @s add gun54recoil
execute if score GLOBAL recoil matches 1 at @s as @s run schedule function thepa:recoil_types/recoil/gun_54_recoil 1t
execute at @s run playsound minigun:bfgfire player @a ~ ~ ~ 10 1
