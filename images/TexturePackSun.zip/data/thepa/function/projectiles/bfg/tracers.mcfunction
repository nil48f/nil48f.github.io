execute as @e[tag=energy_ball] at @s run summon minecraft:armor_stand ^ ^ ^1 {Tags:[bfgray],NoGravity:1b,Marker:1b,Invisible:1b}



execute as @e[tag=bfgtarget] at @s if entity @e[tag=bfgray,distance=..2] run return run tag @s remove bfgtarget

execute as @e[tag=energy_ball] at @s run summon minecraft:armor_stand ^ ^ ^2 {Tags:[bfgray],NoGravity:1b,Marker:1b,Invisible:1b}



execute as @e[tag=bfgtarget] at @s if entity @e[tag=bfgray,distance=..2] run return run tag @s remove bfgtarget

execute as @e[tag=energy_ball] at @s run summon minecraft:armor_stand ^ ^ ^3 {Tags:[bfgray],NoGravity:1b,Marker:1b,Invisible:1b}



execute as @e[tag=bfgtarget] at @s if entity @e[tag=bfgray,distance=..2] run return run tag @s remove bfgtarget

execute as @e[tag=energy_ball] at @s run summon minecraft:armor_stand ^ ^ ^4 {Tags:[bfgray],NoGravity:1b,Marker:1b,Invisible:1b}

execute as @e[tag=bfgtarget] at @s if entity @e[tag=bfgray,distance=..2] run return run tag @s remove bfgtarget
execute as @e[tag=energy_ball] at @s run summon minecraft:armor_stand ^ ^ ^5 {Tags:[bfgray],NoGravity:1b,Marker:1b,Invisible:1b}

execute as @e[tag=bfgtarget] at @s if entity @e[tag=bfgray,distance=..2] run return run tag @s remove bfgtarget

execute as @e[tag=energy_ball] at @s run summon minecraft:armor_stand ^ ^ ^6 {Tags:[bfgray],NoGravity:1b,Marker:1b,Invisible:1b}

execute as @e[tag=bfgtarget] at @s if entity @e[tag=bfgray,distance=..2] run return run tag @s remove bfgtarget
