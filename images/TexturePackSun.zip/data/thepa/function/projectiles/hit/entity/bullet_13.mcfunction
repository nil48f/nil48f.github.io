


execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:0.35d}]}] run function thepa:utilities/resize {"s":"0.25"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:0.5d}]}] run function thepa:utilities/resize {"s":"0.35"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:0.75d}]}] run function thepa:utilities/resize {"s":"0.5"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:1.0d}]}] run function thepa:utilities/resize {"s":"0.75"}
execute as @n[distance=0,nbt=!{attributes:[{id:"minecraft:generic.scale"}]}] run function thepa:utilities/resize {"s":"0.75"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:1.5d}]}] run function thepa:utilities/resize {"s":"1.0"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:2.0d}]}] run function thepa:utilities/resize {"s":"1.5"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:2.5d}]}] run function thepa:utilities/resize {"s":"2.0"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:3.0d}]}] run function thepa:utilities/resize {"s":"2.5"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:3.5d}]}] run function thepa:utilities/resize {"s":"3.0"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:4.0d}]}] run function thepa:utilities/resize {"s":"3.5"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:4.5d}]}] run function thepa:utilities/resize {"s":"4.0"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:5.0d}]}] run function thepa:utilities/resize {"s":"4.5"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:5.5d}]}] run function thepa:utilities/resize {"s":"5.0"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:6.0d}]}] run function thepa:utilities/resize {"s":"5.5"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:6.5d}]}] run function thepa:utilities/resize {"s":"6.0"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:7.0d}]}] run function thepa:utilities/resize {"s":"6.5"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:7.5d}]}] run function thepa:utilities/resize {"s":"7.0"}
execute as @n[distance=0,nbt={attributes:[{id:"minecraft:generic.scale",base:8.0d}]}] run function thepa:utilities/resize {"s":"7.5"}