item modify entity @s[scores= {gz_id=0},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=1..3},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Musket Balls"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=5},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Nether Stars"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=6},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=27},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=7},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Shells"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=8},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Light Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=28},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Light Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=9},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Flares"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=10},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=29},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=11},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=30},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=40},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=12},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Chorus Flowers"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=13},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Chorus Flowers"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=14},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Dragon Shells"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=15},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=31},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=16},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=32},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=17},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=33},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=18},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=34},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=19},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Rockets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=20},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Light Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=35},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Light Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=21},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=41},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=36},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=22},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=38},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=42},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=23},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=39},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=24},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=25},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Lightning"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=26},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses .50 Cal Ammo"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=43},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=44},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Rockets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=45},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Flares"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=46},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=47},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Shells"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=48},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Shells"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=49},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Rockets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=50},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Flares"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=51},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=52},tag=gz_mainhand] weapon.mainhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}


item modify entity @s[scores= {gz_id=0},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=1..3},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Musket Balls"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=5},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Nether Stars"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=6},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=27},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=7},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Shells"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=8},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Light Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=28},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Light Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores= {gz_id=9},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Flares"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=10},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=29},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=11},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=30},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=40},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=12},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Chorus Flowers"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=13},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Chorus Flowers"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=14},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Dragon Shells"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=15},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=31},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=16},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=32},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=17},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=33},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=18},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=34},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Bullets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=19},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Rockets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=20},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Light Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=35},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Light Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=21},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=41},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=36},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=22},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=38},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=42},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=23},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=39},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=24},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=25},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Lightning"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=26},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses .50 Cal Ammo"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=43},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Heavy Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=44},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Rockets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=45},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Flares"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=46},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=47},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Shells"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=48},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Shells"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=49},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Rockets"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=50},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Flares"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=51},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
item modify entity @s[scores={gz_id=52},tag=gz_offhand] weapon.offhand {function:"minecraft:set_lore",lore:[{text:"Uses Medium Rounds"}],entity:"this",mode:"append"}
