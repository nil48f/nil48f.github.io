

give @s minecraft:clock[minecraft:custom_model_data=444456,minecraft:custom_data={"gz_data":{"bullet_type":26b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_26\",\"color\": \"white\",\"italic\": false}"] 3