

give @s minecraft:redstone[minecraft:custom_model_data=88948,minecraft:custom_data={"gz_data":{"lasersight":1b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.lasersight\",\"color\": \"white\",\"italic\": false}"]