

give @s minecraft:clock[minecraft:custom_model_data=444451,minecraft:custom_data={"gz_data":{"bullet_type":7b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_9\",\"color\": \"white\",\"italic\": false}"] 20