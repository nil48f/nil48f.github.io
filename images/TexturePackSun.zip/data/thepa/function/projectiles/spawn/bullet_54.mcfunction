
$execute as @s anchored eyes positioned ^ ^-.2 ^ run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:100,Tags:["gz_projectile","gz_bullet_54","gz_spawn"],CustomName:"\"an BFG 9000\""}
execute as @s run data modify entity @e[type=area_effect_cloud, tag=gz_spawn, limit=1] Rotation set from entity @s Rotation

execute if score GLOBAL bloom matches 1 run function thepa:recoil_types/bloom/bullet_54
execute if score GLOBAL spray matches 1 run function thepa:recoil_types/sprays/bullet_54
execute if score GLOBAL spray matches 1 if entity @s[tag=gz_mainhand] run function thepa:recoil_types/bloom/bullet_54

execute as @e[type=area_effect_cloud, tag=gz_spawn, limit=1,scores={dualiesFire=20..}] run scoreboard players set @s gz_capacity 12

execute as @s anchored eyes positioned ^ ^-.2 ^ run summon item_display ~ ~ ~ {Tags:[energy_ball],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[3f,3f,3f]},item:{id:"minecraft:clock",count:1,components:{"minecraft:custom_model_data":444448}}}

execute as @e[type=area_effect_cloud, tag=gz_spawn] run tag @s remove gz_spawn