execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88890}}}] at @s run playsound minigun:m1reload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88890}}]}] at @s run playsound minigun:m1reload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88889}}}] at @s run playsound minigun:p90reload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88889}}]}] at @s run playsound minigun:p90reload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88888}}}] at @s run playsound minigun:pumpfire master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88888}}]}] at @s run playsound minigun:pumpfire master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88891}}}] at @s run playsound minigun:flarereload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88891}}]}] at @s run playsound minigun:flarereload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88892}}}] at @s run playsound minigun:awpreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88892}}]}] at @s run playsound minigun:awpreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88894}}}] at @s run playsound minigun:huntingreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88894}}]}] at @s run playsound minigun:huntingreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88895}}}] at @s run playsound minigun:akreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88895}}]}] at @s run playsound minigun:akreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88896}}}] at @s run playsound minigun:arreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88896}}]}] at @s run playsound minigun:arreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88897}}}] at @s run playsound minigun:awpreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88897}}]}] at @s run playsound minigun:awpreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88922}}}] at @s run playsound minigun:awpreload master @a[distance=..3] ~ ~ ~ 1 2 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88922}}]}] at @s run playsound minigun:awpreload master @a[distance=..3] ~ ~ ~ 1 2 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88898}}}] at @s run playsound minigun:pistolreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88898}}]}] at @s run playsound minigun:pistolreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88900}}}] at @s run playsound minigun:dualiesreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88900}}]}] at @s run playsound minigun:dualiesreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88901}}}] at @s run playsound minigun:tacreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88901}}]}] at @s run playsound minigun:tacreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88902}}}] at @s run playsound minigun:rayreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88902}}]}] at @s run playsound minigun:rayreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88903}}}] at @s run playsound minigun:rayreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88903}}]}] at @s run playsound minigun:rayreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88905}}}] at @s run playsound minigun:sixreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88905}}]}] at @s run playsound minigun:sixreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88908}}}] at @s run playsound minigun:rocketreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88908}}]}] at @s run playsound minigun:rocketreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88909}}}] at @s run playsound minigun:deagreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88909}}]}] at @s run playsound minigun:deagreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88915}}}] at @s run playsound minigun:lmgreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88915}}]}] at @s run playsound minigun:lmgreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88940}}}] at @s run playsound minigun:awpreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88940}}]}] at @s run playsound minigun:awpreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88941}}}] at @s run playsound minigun:grenadereload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88941}}]}] at @s run playsound minigun:grenadereload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88942}}}] at @s run playsound minigun:flarereload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88942}}]}] at @s run playsound minigun:flarereload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88943}}}] at @s run playsound minigun:autosnipereload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88943}}]}] at @s run playsound minigun:autosnipereload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88944}}}] at @s run playsound minigun:tacshotreload master @a[distance=..3] ~ ~ ~ 2 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88944}}]}] at @s run playsound minigun:tacshotreload master @a[distance=..3] ~ ~ ~ 2 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88945}}}] at @s run playsound minigun:drumshotreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88945}}]}] at @s run playsound minigun:drumshotreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88946}}}] at @s run playsound minigun:quadreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88946}}]}] at @s run playsound minigun:quadreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88947}}}] at @s run playsound minigun:tacshotreload master @a[distance=..3] ~ ~ ~ 2 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88947}}]}] at @s run playsound minigun:tacshotreload master @a[distance=..3] ~ ~ ~ 2 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88949}}}] at @s run playsound minigun:revolverreload master @a[distance=..3] ~ ~ ~ 2 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88949}}]}] at @s run playsound minigun:revolverreload master @a[distance=..3] ~ ~ ~ 2 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":170001}}}] at @s run playsound minigun:revolverreload master @a[distance=..3] ~ ~ ~ 1 1 0.1
execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":170001}}]}] at @s run playsound minigun:revolverreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":444444}}}] at @s run playsound minigun:tommyreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":444444}}]}] at @s run playsound minigun:tommyreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88951}}}] at @s run playsound minigun:augreload master @a[distance=..3] ~ ~ ~ 1 1 0.1

execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88951}}]}] at @s run playsound minigun:augreload master @a[distance=..3] ~ ~ ~ 1 1 0.1


execute if entity @s[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88952}}}] at @s run playsound minigun:bfgreload master @a[distance=..3] ~ ~ ~ 10 1 0.1

execute if entity @s[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88952}}]}] at @s run playsound minigun:bfgreload master @a[distance=..3] ~ ~ ~ 10 1 0.1