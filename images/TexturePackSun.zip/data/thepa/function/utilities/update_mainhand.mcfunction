

scoreboard players reset @s gz_damage
scoreboard players set @s[scores={gz_bullets=..0}] gz_bullets 0
execute unless entity @s[scores={gz_bullets=..0}] run function thepa:utilities/calc_damage

execute store result score @s gz_reload_time run data get entity @s SelectedItem.components.minecraft:custom_data.gz_data.reload_time 1


execute store result storage gz:temp capacity int 1 run scoreboard players get @s gz_capacity
execute store result storage gz:temp bullets int 1 run scoreboard players get @s gz_bullets
execute store result storage gz:temp debuff double 0.1 run data get entity @s SelectedItem.components.minecraft:custom_data.gz_data.debuff 10


#set the bullet data and carrot to warped_fungus_on_a_stick

item modify entity @s[scores={gz_bullets=1..}] weapon.mainhand thepa:crossbow_update
item modify entity @s[scores={gz_id=19,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88920}
item modify entity @s[scores={gz_id=11,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88953}
item modify entity @s[scores={gz_id=30,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88954}
item modify entity @s[scores={gz_id=40,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88955}
item modify entity @s[scores={gz_id=22,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88956}
item modify entity @s[scores={gz_id=38,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88957}
item modify entity @s[scores={gz_id=42,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88958}
item modify entity @s[scores={gz_id=21,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88959}
item modify entity @s[scores={gz_id=36,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88960}
item modify entity @s[scores={gz_id=41,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88961}
item modify entity @s[scores={gz_id=43,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88962}
item modify entity @s[scores={gz_id=46,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88963}
item modify entity @s[scores={gz_id=51,gz_bullets=1..}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88964}





#set the gun to a carrot on stick item
item modify entity @s[scores={gz_bullets=..0}] weapon.mainhand thepa:item_update
item modify entity @s[scores={gz_id=19,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88908}
item modify entity @s[scores={gz_id=11,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88892}
item modify entity @s[scores={gz_id=30,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88926}
item modify entity @s[scores={gz_id=40,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88935}
item modify entity @s[scores={gz_id=22,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88897}
item modify entity @s[scores={gz_id=38,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88922}
item modify entity @s[scores={gz_id=42,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88936}
item modify entity @s[scores={gz_id=21,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88894}
item modify entity @s[scores={gz_id=36,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88932}
item modify entity @s[scores={gz_id=41,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88934}
item modify entity @s[scores={gz_id=43,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88940}
item modify entity @s[scores={gz_id=46,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88943}
item modify entity @s[scores={gz_id=51,gz_bullets=..0}] weapon.mainhand {function:"minecraft:set_custom_model_data",value:88949}

execute if entity @s[scores={gz_bullets=..0}] at @s as @s run function thepa:utilities/apply_item_modifiers