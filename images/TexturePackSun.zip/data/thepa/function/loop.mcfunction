execute as @a at @s store success score @s shootingDelayChecked run scoreboard players get @s shootingdelay
execute as @a if score @s shootingDelayChecked matches 0 run scoreboard players set @s shootingdelay 0

scoreboard players add @e[scores={gz_teslatimer=1..}] gz_teslatimer 1
scoreboard players add @a[tag=gz_shoot,scores={shootingdelay=0}] shootingdelay 1

#Prefs
scoreboard players set @a[tag=!shootinginit] shootingdelay 0
tag @a[scores={shootingdelay=0..}] add shootinginit

scoreboard players set @a[tag=!shootcountinit] shotcounterdelay 0
tag @a[scores={shotcounterdelay=0..}] add shootcountinit


execute as @a unless predicate {"condition":"minecraft:entity_scores","entity":"this","scores":{"killCredit":{}}} store result score @s killCredit run data get entity @s UUID[0]
execute as @a if score @s killCredit matches 0 store result score @s killCredit run data get entity @s UUID[0]

execute as @e[tag=gz_projectile] unless predicate {"condition":"minecraft:entity_scores","entity":"this","scores":{"killCredit":{}}} store result score @s killCredit run data get entity @s Owner[0]


title @a times 0 1 10

scoreboard players add timer ztimer 1
execute if score timer ztimer matches 2.. run scoreboard players set timer ztimer 0


scoreboard players remove @a[scores={shotcounterdelay=0..}] shotcounterdelay 1
scoreboard players set @a[scores={shotcounterdelay=0}] shotcounter 0

execute as @a run function thepa:utilities/player_tick
function thepa:utilities/scopes
function thepa:utilities/shooting_delay
#function thepa:utilities/dolphin
function thepa:utilities/suppress
function thepa:utilities/laserattach
execute as @e[type=area_effect_cloud,tag=gz_projectile] run function thepa:utilities/bullet_tick
#execute at @a as @e[type=item,distance=..10] run function thepa:utilities/item_tick

execute if entity @e[scores={minigunCharge=1..},nbt={SelectedItem:{components:{"minecraft:custom_model_data":666666}}}] run scoreboard players add @e[nbt={SelectedItem:{components:{"minecraft:custom_model_data":666666}}},scores={minigunCharge=1..}] chargeTime 10
execute if entity @e[scores={minigunCharge=1..},nbt={Inventory:[{Slot:-106b, components:{"minecraft:custom_model_data":666666}}]}] run scoreboard players add @e[nbt={Inventory:[{Slot:-106b, components:{"minecraft:custom_model_data":666666}}]},scores={minigunCharge=1..}] chargeTime 10
scoreboard players reset @a[scores={chargeTime=301..}] chargeTime

scoreboard players add @e[type=minecraft:area_effect_cloud,tag=gz_bullet_9] ageflare 1
execute at @e[tag=gz_bullet_9,scores={ageflare=5..6}] as @e[tag=gz_bullet_9,scores={ageflare=5..6}] run effect give @e[distance=..50,type=!armor_stand,type=!donkey] minecraft:glowing 25 0 true
kill @e[tag=gz_bullet_9,scores={ageflare=8..}]



kill @e[type=minecraft:arrow,nbt={damage:15.0d},nbt={inGround:1b}]

execute as @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_model_data":88918}}}] at @s if block ~ ~-1 ~ minecraft:lightning_rod run data merge entity @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_model_data":88918}}},limit=1] {Invulnerable:1b}

execute as @e[type=minecraft:item,nbt={Fire:150s,Item:{components:{"minecraft:custom_model_data":88918}}}] at @s if block ~ ~-1 ~ minecraft:lightning_rod as @p run function thepa:give/tesla_gun

execute as @e[type=minecraft:item,nbt={Fire:149s,Item:{components:{"minecraft:custom_model_data":88918}}}] at @s if block ~ ~-1 ~ minecraft:lightning_rod run kill @s


execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{gz_data:{laser:1b}}}}}] run tag @s add gunsight
execute as @a[nbt={Inventory:[{Slot: -106b, components:{"minecraft:custom_data":{gz_data:{laser:1b}}}}]}] run tag @s add gunsight
execute as @a[nbt=!{SelectedItem:{components:{"minecraft:custom_data":{gz_data:{laser:1b}}}}},nbt=!{Inventory:[{Slot: -106b, components:{"minecraft:custom_data":{gz_data:{laser:1b}}}}]}] run tag @s remove gunsight

execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_data":{gz_data:{laser:1b}}}}}] run function thepa:utilities/lasersight
execute as @a[nbt={Inventory:[{Slot: -106b, components:{"minecraft:custom_data":{gz_data:{laser:1b}}}}]}] run function thepa:utilities/lasersight

function thepa:projectiles/hit/entity/laser

execute as @a[scores={gz_crossbow=1..},nbt={SelectedItem:{components:{"minecraft:custom_data":{gz_data:{}}}}}] at @s run function thepa:shoot/trigger
execute as @a[scores={gz_crossbow=1..},nbt={Inventory:[{Slot:-106b, components:{"minecraft:custom_data":{gz_data:{}}}}]}] at @s run function thepa:shoot/trigger

function thepa:turret/functionality

scoreboard players set @a minigunCharge 0
scoreboard players set @a gz_click 0
scoreboard players set @a gz_crossbow 0
scoreboard players set @a gz_sneak 0


execute as @a at @s store result score @s rotation_x run data get entity @s Rotation[0]
execute as @a at @s if score @s rotation_x matches ..0 run scoreboard players add @s rotation_x 360


#Spawn Turret
execute as @e[type=armor_stand,tag=spawn_turret] at @s run tp @s ~ ~ ~ facing entity @p
execute as @e[type=armor_stand,tag=spawn_turret] at @s run data modify entity @s Rotation[1] set value 0.0f
execute as @e[type=armor_stand,tag=spawn_turret] at @s run function thepa:turret/spawn_turret
execute as @e[tag=turretT,scores={max_x=360..}] run scoreboard players remove @s max_x 360
execute as @e[tag=turretT,scores={min_x=..0}] run scoreboard players add @s min_x 360



#kill Turret
execute as @e[tag=turretB] at @s unless entity @e[tag=turretH,distance=..1.8] run kill @s
execute as @e[tag=turretT] at @s unless entity @e[tag=turretH,distance=..1.8] run kill @s
execute as @e[tag=turretC] at @s unless entity @e[tag=turretH,distance=..1.8] run kill @s


execute as @e[tag=motion_added,nbt={OnGround:1b}] at @s run function thepa:projectiles/apply_y
execute as @e[tag=motion_added] at @s store result score @s SCOREBOARD1 run data get entity @s Motion[0] 150


execute as @e[tag=motion_projectile,tag=!motion_added] at @s rotated as @p run function thepa:projectiles/apply_motion
execute as @e[tag=motion_projectile] at @e[tag=motion_projectile] unless block ~ ~-0.5 ~ #thepa:air run tag @s remove motion_projectile

execute as @e[tag=motion_projectile2,tag=!motion_added2] at @s rotated as @p run function thepa:projectiles/apply_motion2
execute as @e[tag=motion_projectile2] at @e[tag=motion_projectile2] unless block ~ ~-0.5 ~ #thepa:air run data merge entity @e[tag=motion_projectile2,limit=1] {Fuse:0}

execute as @a[tag=!recipeggiven] run function thepa:give/recipe_book
execute as @a[tag=!recipeggiven] run function thepa:utilities/recipes
tag @a add recipeggiven

execute as @a[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88952}}},scores={bfgidle=1}] at @s run playsound minigun:bfgidle player @s ~ ~ ~ 10 1


execute as @a[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88952}}]},scores={bfgidle=1}] at @s run playsound minigun:bfgidle player @s ~ ~ ~ 10 1


#BFG 
function thepa:projectiles/bfg/loop

execute as @a[scores={deathCount=1..}] run attribute @s minecraft:generic.scale base set 1
scoreboard players reset @a[scores={deathCount=1..}] deathCount