scoreboard players add @a[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88952,"minecraft:custom_data":{gz_data:{bullets:20}}}}}] bfgidle 1
scoreboard players reset @a[nbt={SelectedItem:{components:{"minecraft:custom_model_data":88952,"minecraft:custom_data":{gz_data:{bullets:0}}}}}] bfgidle
execute as @a[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88952}}]}] unless entity @a[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88952}}]}] run stopsound @s player minigun:bfgidle
scoreboard players add @a[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88952,"minecraft:custom_data":{gz_data:{bullets:20}}}}]}] bfgidle 1
scoreboard players reset @a[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88952,"minecraft:custom_data":{gz_data:{bullets:0}}}}]}] bfgidle
execute as @a[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88952}}]}] unless entity @a[nbt={Inventory:[{Slot: -106b,components:{"minecraft:custom_model_data":88952}}]}] run stopsound @s player minigun:bfgidle
scoreboard players reset @a[scores={bfgidle=55..}] bfgidle


execute if entity @e[tag=bfgtarget] run function thepa:projectiles/bfg/tracers
execute if entity @e[tag=energy_ball] run function thepa:projectiles/bfg/rotate
execute if entity @e[tag=energy_ball] run function thepa:projectiles/bfg/bfgtags