

give @s minecraft:clock[minecraft:custom_model_data=444453,minecraft:custom_data={"gz_data":{"bullet_type":14b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_14\",\"color\": \"white\",\"italic\": false}"]