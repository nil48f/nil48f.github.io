

give @s minecraft:clock[minecraft:custom_model_data=444450,minecraft:custom_data={"gz_data":{"bullet_type":9b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_8\",\"color\": \"white\",\"italic\": false}"]