
function thepa:projectiles/spawn/bullet_18 with entity @s

execute anchored eyes positioned ^ ^1.5 ^1.5 run particle minecraft:explosion ~ ~ ~ 0 0 0 0 1

execute if score GLOBAL camera matches 1 run function thepa:recoil_types/camera/gun_18


execute if score GLOBAL recoil matches 1 run tag @s add gun18recoil
execute if score GLOBAL recoil matches 1 at @s as @s run schedule function thepa:recoil_types/recoil/gun_18_recoil 1t
execute at @s run playsound minigun:pistolshoot player @a ~ ~ ~ 0.3 1


