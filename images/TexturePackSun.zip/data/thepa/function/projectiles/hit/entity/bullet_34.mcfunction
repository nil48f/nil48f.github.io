

#0.6
execute if entity @n[type=#thepa:affected,tag=gz_headshot,distance=0] as @a if score @s killCredit = @n[type=area_effect_cloud,tag=gz_projectile,distance=..5] killCredit run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 10 2
execute as @a if score @s killCredit = @n[type=area_effect_cloud,tag=gz_projectile,distance=..5] killCredit run damage @n[type=#thepa:affected,tag=gz_headshot,distance=0] .6 thepa:shot by @s

#0.15
execute as @a if score @s killCredit = @n[type=area_effect_cloud,tag=gz_projectile,distance=..5] killCredit run damage @n[type=#thepa:affected,tag=!gz_headshot,distance=0] .125 thepa:shot by @s

execute if entity @e[type=minecraft:ender_dragon,sort=nearest,limit=1,distance=0] run damage @e[type=minecraft:ender_dragon,sort=nearest,limit=1,distance=0] 0.6 minecraft:player_explosion by @s

tag @e remove gz_headshot
