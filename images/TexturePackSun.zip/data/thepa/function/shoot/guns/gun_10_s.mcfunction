
function thepa:projectiles/spawn/bullet_10 with entity @s

execute anchored eyes positioned ^ ^1.5 ^1.5 run particle minecraft:explosion ~ ~ ~ 0 0 0 0 1

execute if score GLOBAL camera matches 1 run function thepa:recoil_types/camera/gun_10_s


execute if score GLOBAL recoil matches 1 run tag @s add gun10srecoil
execute if score GLOBAL recoil matches 1 at @s as @s run schedule function thepa:recoil_types/recoil/gun_10_s_recoil 1t
execute at @s run playsound minigun:m1fire player @a[distance=..10] ~ ~ ~ 0.5 2