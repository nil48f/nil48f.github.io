
function thepa:projectiles/spawn/bullet_29 with entity @s

execute anchored eyes positioned ^ ^1.5 ^1.5 run particle minecraft:explosion ~ ~ ~ 0 0 0 0 1

execute if score GLOBAL camera matches 1 run function thepa:recoil_types/camera/gun_29


execute if score GLOBAL recoil matches 1 run tag @s add gun29recoil
execute if score GLOBAL recoil matches 1 at @s as @s run schedule function thepa:recoil_types/recoil/gun_29_recoil 1t
execute at @s run playsound minigun:flarefire player @a ~ ~ ~ 0.3 1