title @a[nbt={Inventory:[{Slot:-106b,id:"minecraft:warped_fungus_on_a_stick",components:{"minecraft:custom_data":{gz_data:{sniper:1b}}}}]}] title [{"text":"","color":"#4e5c24"},{"text":"\u4698"}]

execute as @a[nbt={Inventory:[{Slot:-106b,id:"minecraft:warped_fungus_on_a_stick",components:{"minecraft:custom_data":{gz_data:{sniper:1b}}}}]}] run tag @s add scoping
execute as @a[tag=scoping,nbt=!{Inventory:[{Slot:-106b,id:"minecraft:warped_fungus_on_a_stick",components:{"minecraft:custom_data":{gz_data:{sniper:1b}}}}]}] run title @s title ""
execute as @a[nbt=!{Inventory:[{Slot:-106b,id:"minecraft:warped_fungus_on_a_stick",components:{"minecraft:custom_data":{gz_data:{sniper:1b}}}}]}] run tag @s remove scoping

title @a[nbt={Inventory:[{Slot:-106b,components:{"minecraft:custom_model_data":88920}}]}] title [{"text":"","color":"#4e5c24"},{"text":"\u4699"}]

execute as @a[nbt={Inventory:[{Slot:-106b,components:{"minecraft:custom_model_data":88920}}]}] run tag @s add rpgscoping
execute as @a[tag=rpgscoping,nbt=!{Inventory:[{Slot:-106b,components:{"minecraft:custom_model_data":88920}}]}] run title @s title ""
execute as @a[nbt=!{Inventory:[{Slot:-106b,components:{"minecraft:custom_model_data":88920}}]}] run tag @s remove rpgscoping




title @a[nbt={Inventory:[{Slot:-106b,components:{"minecraft:custom_model_data":88951}}]}] title [{"text":"","color":"#4e5c24"},{"text":"\u469b"}]
execute as @a[nbt={Inventory:[{Slot:-106b,components:{"minecraft:custom_model_data":88951}}]}] run tag @s add augscoping
execute as @a[tag=augscoping,nbt=!{Inventory:[{Slot:-106b,components:{"minecraft:custom_model_data":88951}}]}] run title @s title ""
execute as @a[nbt=!{Inventory:[{Slot:-106b,components:{"minecraft:custom_model_data":88951}}]}] run tag @s remove augscoping