
scoreboard players add @s gz_bullets 1
tp @s ^ ^ ^0.5
execute store result score @s[tag=!gz_bullet_5,tag=!gz_bullet_9,tag=!gz_bullet_27,tag=!gz_bullet_12,tag=!gz_bullet_13,tag=!gz_bullet_14,tag=!gz_bullet_19,tag=!gz_bullet_54,tag=!gz_bullet_7,tag=!gz_bullet_31,tag=!gz_bullet_32] particledelay run data get entity @s Age 1

execute as @e[tag=gz_bullet_5] at @s run particle minecraft:electric_spark ~ ~1 ~ 0 0 0 0 1 force @a
execute as @e[tag=gz_bullet_9] at @s run particle minecraft:flame ~ ~1 ~ 0 0 0 0 1 force @a
execute as @e[tag=gz_bullet_27] at @s run particle minecraft:flame ~ ~1 ~ 0 0 0 0 1 force @a
execute as @e[tag=gz_bullet_12] at @s run particle minecraft:soul_fire_flame ~ ~1 ~ 0 0 0 0 1 force @a
execute as @e[tag=gz_bullet_13] at @s run particle minecraft:squid_ink ~ ~1 ~ 0 0 0 0 1 force @a
execute as @e[tag=gz_bullet_14] at @s run particle minecraft:smoke ~ ~1 ~ 0 0 0 0 1 force @a
execute as @e[tag=gz_bullet_19] at @s run playsound minigun:rockettrail master @a[distance=10..30] ~ ~ ~ 1 1
execute as @e[tag=gz_bullet_19] at @s run particle minecraft:squid_ink ~ ~1 ~ 0 0 0 0 1 force @a

execute if score @s[tag=!gz_bullet_5,tag=!gz_bullet_9,tag=!gz_bullet_27,tag=!gz_bullet_12,tag=!gz_bullet_13,tag=!gz_bullet_14,tag=!gz_bullet_19,tag=!gz_bullet_54,tag=!gz_bullet_7,tag=!gz_bullet_31,tag=!gz_bullet_32] particledelay matches 1.. as @s at @s run particle minecraft:smoke ~ ~ ~ 0 0 0 0 1 normal @a

execute as @e[tag=gz_bullet_14] at @s run tp @e[tag=gz_fireball,limit=1,sort=nearest] @s

execute as @e[tag=gz_fireball] at @s unless entity @e[tag=gz_bullet_14,limit=1,sort=nearest,distance=..5] run kill @s

execute unless score @s killCredit = @n[type=#thepa:affected,dx=0,dy=0,dz=0] killCredit as @e[type=#thepa:affected,dx=0,dy=0,dz=0,tag=!gz_shoot] at @s run function thepa:projectiles/detect_hitbox

execute at @e[tag=gz_bullet_9] as @e[tag=gz_bullet_9] run fill ~ ~ ~ ~ ~ ~ fire replace air
execute at @e[tag=gz_bullet_27] as @e[tag=gz_bullet_27] run fill ~-0.5 ~-0.5 ~-0.5 ~0.5 ~ ~0.5 fire replace air

execute as @e[tag=gz_bullet_54] at @s run tp @n[tag=energy_ball] ~ ~ ~
execute as @e[tag=energy_ball] at @s if entity @n[tag=gz_bullet_54,nbt={Age:49},distance=..3] run kill @s

execute unless block ~ ~ ~ #thepa:non_solid run function thepa:projectiles/hit/block/select
execute if entity @s[tag=gz_hit] at @s run function thepa:projectiles/hit/entity/select

execute unless entity @s[tag=gz_hit] if score @s gz_bullets < @s gz_capacity at @s run function thepa:projectiles/move