
execute if block ~ ~ ~ minecraft:bell run playsound block.bell.use block @a[distance=..30] ~ ~ ~ 50
execute if block ~ ~ ~ minecraft:chorus_flower run function thepa:projectiles/hit/block/destroy

