

give @s minecraft:clock[minecraft:custom_model_data=444457,minecraft:custom_data={"gz_data":{"bullet_type":54b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_54\",\"color\": \"white\",\"italic\": false}"] 2