$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet1"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet2"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet3"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet4"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet5"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet6"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet7"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet8"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet9"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet10"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet11"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet12"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet13"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet14"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet15"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet16"],CustomName:"\"a Longarm Enforcer Shotgun\""}
$execute as @s anchored eyes positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Owner:$(UUID),Duration:15,Tags:["gz_projectile","gz_bullet_31","gz_spawn","bullet17"],CustomName:"\"a Longarm Enforcer Shotgun\""}

execute as @e[type=area_effect_cloud, tag=gz_spawn,tag=gz_bullet_31] run data modify entity @s Rotation set from entity @a[sort=nearest,limit=1] Rotation

execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet1, limit=1] ^ ^1 ^1 ~ ~
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet2, limit=1] ^ ^1 ^1 ~4 ~4
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet3, limit=1] ^ ^1 ^1 ~ ~4
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet4, limit=1] ^ ^1 ^1 ~-4 ~
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet5, limit=1] ^ ^1 ^1 ~-2.5 ~2.5
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet6, limit=1] ^ ^1 ^1 ~-4 ~-4
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet7, limit=1] ^ ^1 ^1 ~ ~-4
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet8, limit=1] ^ ^1 ^1 ~4 ~-4
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet9, limit=1] ^ ^1 ^1 ~-4 ~4
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet10, limit=1] ^ ^1 ^1 ~2.5 ~
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet11, limit=1] ^ ^1 ^1 ~2.5 ~2.5
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet12, limit=1] ^ ^1 ^1 ~ ~2.5
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet13, limit=1] ^ ^1 ^1 ~-2.5 ~
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet14, limit=1] ^ ^1 ^1 ~-2.5 ~-2.5
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet15, limit=1] ^ ^1 ^1 ~ ~-2.5
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet16, limit=1] ^ ^1 ^1 ~2.5 ~-2.5
execute as @s[tag=gz_mainhand] at @s[tag=gz_mainhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet17, limit=1] ^ ^1 ^1 ~4 ~


execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet1, limit=1] ^ ^1 ^1 ~ ~
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet2, limit=1] ^ ^1 ^1 ~1.5 ~1.5
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet3, limit=1] ^ ^1 ^1 ~ ~1.5
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet4, limit=1] ^ ^1 ^1 ~-1.5 ~
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet5, limit=1] ^ ^1 ^1 ~-1 ~1
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet6, limit=1] ^ ^1 ^1 ~-1.5 ~-1.5
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet7, limit=1] ^ ^1 ^1 ~ ~-1.5
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet8, limit=1] ^ ^1 ^1 ~1.5 ~-1.5
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet9, limit=1] ^ ^1 ^1 ~-1.5 ~1.5
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet10, limit=1] ^ ^1 ^1 ~1 ~
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet11, limit=1] ^ ^1 ^1 ~1 ~1
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet12, limit=1] ^ ^1 ^1 ~ ~1
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet13, limit=1] ^ ^1 ^1 ~-1 ~
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet14, limit=1] ^ ^1 ^1 ~-1 ~-1
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet15, limit=1] ^ ^1 ^1 ~ ~-1
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet16, limit=1] ^ ^1 ^1 ~1 ~-1
execute as @s[tag=gz_offhand] at @s[tag=gz_offhand] run tp @e[type=area_effect_cloud, tag=gz_spawn, tag=bullet17, limit=1] ^ ^1 ^1 ~1.5 ~


execute as @e[type=area_effect_cloud, tag=gz_spawn] run scoreboard players set @s gz_capacity 9
execute as @e[type=area_effect_cloud, tag=gz_spawn] run tag @s remove gz_spawn