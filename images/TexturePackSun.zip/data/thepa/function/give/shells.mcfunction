

give @s minecraft:clock[minecraft:custom_model_data=170030,minecraft:custom_data={"gz_data":{"bullet_type":2b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_2\",\"color\": \"white\",\"italic\": false}"] 2