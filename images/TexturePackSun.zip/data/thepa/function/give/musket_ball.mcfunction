

give @s minecraft:clock[minecraft:custom_model_data=444454,minecraft:custom_data={"gz_data":{"bullet_type":3b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_3\",\"color\": \"white\",\"italic\": false}"]