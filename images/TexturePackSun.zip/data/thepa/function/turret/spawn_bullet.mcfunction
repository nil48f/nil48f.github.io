
execute as @s anchored feet positioned ^ ^1 ^1 run summon area_effect_cloud ~ ~ ~ {Age:0,Duration:40,Tags:["gz_projectile","gz_bullet_99","gz_spawn"],CustomName:"\"an M2 Browning\""}

execute as @s run data modify entity @e[type=area_effect_cloud, tag=gz_spawn, limit=1] Rotation set from entity @s Rotation

execute as @e[type=area_effect_cloud, tag=gz_spawn, limit=1] run scoreboard players set @s gz_capacity 12
execute as @e[type=area_effect_cloud, tag=gz_spawn] run tag @s remove gz_spawn

playsound minigun:lmgshoot master @a[distance=..5] ~ ~ ~ 2 1