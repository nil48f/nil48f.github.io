

give @s minecraft:clock[minecraft:custom_model_data=170010,minecraft:custom_data={"gz_data":{"bullet_type":0b},"HideFlags":32},minecraft:item_name="{\"translate\": \"thepa.item.name.bullet_0\",\"color\": \"white\",\"italic\": false}"] 6